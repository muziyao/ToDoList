package com;

import org.apache.catalina.Session;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest rq, HttpServletResponse rp, Object handler) throws Exception {
        System.out.println("进来preHandle");
        System.err.println(rq.getSession().getId());
        System.err.println(rq.getRequestedSessionId());
        System.err.println(rq.getRequestedSessionId().equals(rq.getSession().getId()));
        if (rq.getRequestedSessionId().equals(rq.getSession().getId())){
            return true;
        }

        rp.getOutputStream().write("session已过期".getBytes("UTF-8"));
        return false;
    }

    @Override
    public void postHandle(HttpServletRequest rq, HttpServletResponse rp, Object handler, ModelAndView modelAndView) throws Exception {
        System.out.println("进来postHandle");
    }

    @Override
    public void afterCompletion(HttpServletRequest rq, HttpServletResponse rp, Object handler, Exception ex) throws Exception {
        System.out.println("进来afterCompletion");
    }
}
