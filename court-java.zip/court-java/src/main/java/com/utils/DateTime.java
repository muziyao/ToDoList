package com.utils;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class DateTime {
    /*
    * 获取当前年月日
    * */
    public static String getToDayYearMonthDate(){
        Calendar calendar= Calendar.getInstance();
        return calendar.get(GregorianCalendar.YEAR) + "-" +
                (calendar.get(GregorianCalendar.MONTH) + 1) + "-" +
                calendar.get(GregorianCalendar.DAY_OF_MONTH);
    }

}
