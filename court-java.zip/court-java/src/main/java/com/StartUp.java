package com;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.core.StandardContext;
import org.apache.catalina.startup.Tomcat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.util.descriptor.web.FilterDef;
import org.apache.tomcat.util.descriptor.web.FilterMap;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.filter.CharacterEncodingFilter;

// swagger 访问地址： http://localhost:9983/court/swagger-ui.html

public class StartUp{
	protected static final Logger logger = LogManager.getLogger();
		public static void main(String[] args) throws  Exception {
			  	    Tomcat tomcat = new Tomcat();
			  	    //tomcat.setHostname("yao863607738.yicp.vip");
				    tomcat.setPort(9983);
				    StandardContext ctx = (StandardContext) 
						  tomcat.addWebapp("/court", 
		        	   new File("static").getAbsolutePath()  );

				    initEncoding(ctx);
					initCosFilter(ctx);

			        
	        tomcat.start();
	        tomcat.getServer().await();
	          
		}
		
		private static void initEncoding(StandardContext ctx) {
			   
	        FilterDef filterde = new FilterDef();
	        filterde.addInitParameter("encoding", "UTF-8");
	        filterde.setFilter( new CharacterEncodingFilter());
	        filterde.setFilterName(CharacterEncodingFilter.class.getSimpleName());
	        ctx.addFilterDef( filterde  );
	        FilterMap filter1mapping = new FilterMap(); 
	        filter1mapping.setFilterName(CharacterEncodingFilter.class.getSimpleName()); 
	        filter1mapping.addURLPattern("/*"); 
	        ctx.addFilterMap(filter1mapping); 
		}

		/**
		 * 未调用。如果需求可以在此处使用。
		 * 过滤器初始化  
		 * @param ctx
		 * @throws InstantiationException
		 * @throws IllegalAccessException
		 */
		private static void initCosFilter( StandardContext ctx  ) throws InstantiationException, IllegalAccessException {
			FilterDef filterde = new FilterDef();
			Filter ft = new Filter() {
				@Override
				public void init(FilterConfig arg0) throws ServletException { }
				
				@Override
				public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
						throws IOException, ServletException {
					 HttpServletResponse rp = (HttpServletResponse) arg1;
					 rp.setHeader("Access-Control-Allow-Origin", "*");  
					 rp.setHeader("Access-Control-Allow-Methods", "*");  
					 rp.setHeader("Access-Control-Allow-Headers", "*");
					arg2.doFilter(arg0, arg1);
				}
				
				@Override
				public void destroy() { }
			};
			filterde.setFilter(ft);
			filterde.setFilterName(ft.getClass().getName());
			ctx.addFilterDef(filterde);
			FilterMap filter1mapping = new FilterMap();
			filter1mapping.setFilterName(ft.getClass().getName());
			filter1mapping.addURLPattern("/*");
			ctx.addFilterMap(filter1mapping);
			 
		}
		
		
		
	 
		 
}
