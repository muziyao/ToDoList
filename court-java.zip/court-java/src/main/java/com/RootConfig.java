package com;


import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.mapper.MapperScannerConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ClassPathResource;

import com.alibaba.druid.pool.DruidDataSource;

@Configuration
@ComponentScan(basePackages= {"com.court.service.impl" })
public class RootConfig {

	private static DataSource getDs() {
		DruidDataSource ds = new DruidDataSource(); 
		ds.setUrl("jdbc:mysql://localhost:3306/court?characterEncoding=UTF-8&useSSL=false");
		ds.setDriverClassName("com.mysql.jdbc.Driver");
		ds.setUsername("root");
		ds.setPassword("863607738");
		return ds;
	}
	@Bean("sqlsessionfactory")
	public SqlSessionFactoryBean  getBean0() {
		SqlSessionFactoryBean sqlbean = new SqlSessionFactoryBean();
		sqlbean.setDataSource( getDs() );
		sqlbean.setConfigLocation( new ClassPathResource("conf.xml")  );
		return sqlbean;
	}
	
	@Bean
	public MapperScannerConfigurer getBean1() {
		MapperScannerConfigurer mpscfg = new MapperScannerConfigurer();
		mpscfg.setSqlSessionFactoryBeanName("sqlsessionfactory");
		mpscfg.setBasePackage("com.court.mapper");
		return mpscfg;
	}
}
