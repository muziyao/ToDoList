package com.court.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

@ApiModel(value="Task对象", description="")
public class Task implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty("待办事务的序号标识")
    private int id;

    @ApiModelProperty("用户添加的待办事务")
    private String affair;

    @ApiModelProperty("用户添加待办事务的时间")
    private String times;

    @ApiModelProperty("用户的待办事务完成状态")
    private String state;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAffair() {
        return affair;
    }

    public void setAffair(String affair) {
        this.affair = affair;
    }

    public String getTimes() {
        return times;
    }

    public void setTimes(String times) {
        this.times = times;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", affair='" + affair + '\'' +
                ", times='" + times + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
