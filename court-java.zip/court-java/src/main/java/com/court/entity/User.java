package com.court.entity;

import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * 
 * </p>
 *
 * @author haiger412
 * @since 2019-10-07
 */
@ApiModel(value="User对象", description="")
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("用户在微信小程序下的openid")
    private String openId;

    @ApiModelProperty("用户在微信昵称")
    private String wxNickname;

    @ApiModelProperty("用户在微信头像")
    private String wxCover;

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getWxNickname() {
        return wxNickname;
    }

    public void setWxNickname(String wxNickname) {
        this.wxNickname = wxNickname;
    }

    public String getWxCover() {
        return wxCover;
    }

    public void setWxCover(String wxCover) {
        this.wxCover = wxCover;
    }

    @Override
    public String toString() {
        return "User{" +
                "openId='" + openId + '\'' +
                ", wxNickname='" + wxNickname + '\'' +
                ", wxCover='" + wxCover + '\'' +
                '}';
    }
}
