package com.court.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

@ApiModel(value="UserTask对象", description="")
public class UserTask implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty("用户与待办事务之间的序号标识")
    private int id;

    @ApiModelProperty("用户在微信小程序下的openid")
    private String openId;

    @ApiModelProperty("待办事务的序号标识")
    private int taskId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    @Override
    public String toString() {
        return "UserTask{" +
                "id=" + id +
                ", openId='" + openId + '\'' +
                ", taskId='" + taskId + '\'' +
                '}';
    }
}
