package com.court.entity;
 
import java.time.LocalTime;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * 
 * </p>
 *
 * @author haiger412
 * @since 2019-10-07
 */
@ApiModel(value="Shop对象", description="")
public class Shop implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer shopId;

    private String name;

    private String tel;

    private String address;

    private String account;

    private String password;

    private String wxNum;

    private LocalTime opentime;

    private LocalTime closetime;

    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getWxNum() {
        return wxNum;
    }

    public void setWxNum(String wxNum) {
        this.wxNum = wxNum;
    }
    public LocalTime getOpentime() {
        return opentime;
    }

    public void setOpentime(LocalTime opentime) {
        this.opentime = opentime;
    }
    public LocalTime getClosetime() {
        return closetime;
    }

    public void setClosetime(LocalTime closetime) {
        this.closetime = closetime;
    }

    @Override
    public String toString() {
        return "Shop{" +
            "shopId=" + shopId +
            ", name=" + name +
            ", tel=" + tel +
            ", address=" + address +
            ", account=" + account +
            ", password=" + password +
            ", wxNum=" + wxNum +
            ", opentime=" + opentime +
            ", closetime=" + closetime +
        "}";
    }
}
