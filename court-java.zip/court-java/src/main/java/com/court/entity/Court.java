package com.court.entity;

 
import java.io.Serializable;
import io.swagger.annotations.ApiModel;

/**
 * <p>
 * 
 * </p>
 *
 * @author haiger412
 * @since 2019-10-07
 */
@ApiModel(value="Court对象", description="")
public class Court implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    private Integer shopId;

    private String name;

    private String cover;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    @Override
    public String toString() {
        return "Court{" +
            "id=" + id +
            ", shopId=" + shopId +
            ", name=" + name +
            ", cover=" + cover +
        "}";
    }
}
