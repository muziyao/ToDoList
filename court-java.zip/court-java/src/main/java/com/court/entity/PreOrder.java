package com.court.entity;

import java.time.LocalDateTime;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * <p>
 * 
 * </p>
 *
 * @author haiger412
 * @since 2019-10-07
 */
@ApiModel(value="PreOrder对象", description="")
public class PreOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer id;

    private Integer courtId;

    private Integer shopId;

    private LocalDateTime opentime;

    private LocalDateTime closetime;

    private String userid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getCourtId() {
        return courtId;
    }

    public void setCourtId(Integer courtId) {
        this.courtId = courtId;
    }
    public Integer getShopId() {
        return shopId;
    }

    public void setShopId(Integer shopId) {
        this.shopId = shopId;
    }
    public LocalDateTime getOpentime() {
        return opentime;
    }

    public void setOpentime(LocalDateTime opentime) {
        this.opentime = opentime;
    }
    public LocalDateTime getClosetime() {
        return closetime;
    }

    public void setClosetime(LocalDateTime closetime) {
        this.closetime = closetime;
    }
    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    @Override
    public String toString() {
        return "PreOrder{" +
            "id=" + id +
            ", courtId=" + courtId +
            ", shopId=" + shopId +
            ", opentime=" + opentime +
            ", closetime=" + closetime +
            ", userid=" + userid +
        "}";
    }
}
