package com.court.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.court.entity.User;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author haiger412
 * @since 2019-10-07
 */
public interface UserMapper extends BaseMapper<User> {
      List<User> getAll();

      void inserts(User user);

      User queryOpenid(String openId);
}
