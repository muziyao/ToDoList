package com.court.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.court.entity.Task;
import com.court.entity.UserTask;

import java.util.List;

public interface UserTaskMapper extends BaseMapper<UserTask> {
    List<UserTask> getAll();

    void inserts(UserTask userTask);

    void deleteUserTask(List<Task> task);

    void deleteAll(String times);
}
