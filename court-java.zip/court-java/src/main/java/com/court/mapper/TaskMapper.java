package com.court.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.court.entity.Task;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface TaskMapper extends BaseMapper<Task> {
    List<Task> getAll(@Param("openId") String openId, @Param("times") String times);

    void inserts(Task task);

    int queryLastId();

    void deleteTask(List<Task> task);

    void updateTask(List<Task> task);

    void deleteAll(String times);
}
