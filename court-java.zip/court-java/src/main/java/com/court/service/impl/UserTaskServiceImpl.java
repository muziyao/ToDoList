package com.court.service.impl;

import com.court.entity.UserTask;
import com.court.mapper.UserTaskMapper;
import com.court.service.IUserTaskService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class UserTaskServiceImpl extends ServiceImpl<UserTaskMapper, UserTask> implements IUserTaskService {

}
