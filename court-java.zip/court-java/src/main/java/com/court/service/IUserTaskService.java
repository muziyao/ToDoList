package com.court.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.court.entity.UserTask;

public interface IUserTaskService extends IService<UserTask> {
}
