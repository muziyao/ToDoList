package com.court.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.court.entity.Court;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author haiger412
 * @since 2019-10-07
 */
public interface ICourtService extends IService<Court> {

}
