package com.court.service.impl;

import com.court.entity.Court;
import com.court.mapper.CourtMapper;
import com.court.service.ICourtService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author haiger412
 * @since 2019-10-07
 */
@Service
public class CourtServiceImpl extends ServiceImpl<CourtMapper, Court> implements ICourtService {

}
