package com.court.service.impl;

import com.court.entity.Task;
import com.court.mapper.TaskMapper;
import com.court.service.ITaskService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class TaskServiceImpl extends ServiceImpl<TaskMapper, Task> implements ITaskService {

}
