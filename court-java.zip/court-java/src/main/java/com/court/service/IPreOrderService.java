package com.court.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.court.entity.PreOrder;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author haiger412
 * @since 2019-10-07
 */
public interface IPreOrderService extends IService<PreOrder> {

}
