package com.court.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.court.entity.Task;

public interface ITaskService extends IService<Task> {

}
