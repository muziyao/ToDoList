package com.court.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.UUID;


import com.utils.HttpRequest;
import net.sf.json.JSONObject;

import com.court.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.court.entity.User;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author haiger412
 * @since 2019-10-07
 */
//  http://localhost:9983/court/user/getall.action
@RestController
@RequestMapping("/user")
@Api(tags = "用户接口")
public class UserController {

	@Autowired
	private UserMapper ump;


	@GetMapping("/getAll.action")
	@ApiOperation(value = "获取所有用户")
	public List<User> getAll( ){
		return ump.getAll() ;
	}

    @GetMapping("/getUser.action")
    @ApiOperation(value = "获取指定openid的用户")
    public User getUser(HttpServletRequest rq, HttpServletResponse rp) throws IOException {
	    String uuid = rq.getHeader("uuid");
        HttpSession session = rq.getSession();
        session.getAttribute(uuid);
        System.out.println(session.getAttribute(uuid));
	    return ump.queryOpenid(rq.getParameter("openId"));
    }

    @GetMapping("/getOpenid")
    @ApiOperation(value = "从前台获取的openid进行解析")
    public Map gettingOpenId(HttpServletRequest rq,HttpServletResponse rp,
                             @RequestParam("code") String code){

        System.out.println("进来了getOpenid请求");
        User u = new User();
        u.setWxNickname(rq.getParameter("wxNickname"));
        u.setWxCover(rq.getParameter("wxCover"));
        Map map=new HashMap();
        //登录凭证不能为空
        if (code == null || code.length() == 0) {
            map.put("status", 0);
            map.put("msg", "code 不能为空");
        }
        //小程序唯一标识   (在微信小程序管理后台获取)
        String wxspAppid = "wx375fbd2d0a596b07";
        //小程序的 app secret (在微信小程序管理后台获取)
        String wxspSecret = "006580178b5e72da4b50f0ee134f48d6";
        //授权（必填）
        String grant_type = "authorization_code";

        // 1、向微信服务器 使用登录凭证 code 获取 session_key 和 openid
        //请求参数
        String params = "appid=" + wxspAppid + "&secret=" + wxspSecret + "&js_code=" + code + "&grant_type=" + grant_type;
        //发送请求
        String sr = HttpRequest.sendGet("https://api.weixin.qq.com/sns/jscode2session", params);
        //解析相应内容（转换成json对象）
        JSONObject json = JSONObject.fromObject(sr);
        //用户的唯一标识（openid）
        String openid = (String) json.get("openid");
        String session_key = (String) json.get("session_key");
        System.err.println("openId为"+openid);
        System.err.println("session_key为"+session_key);
        u.setOpenId(openid);
        //将openid和session_key设置到session中。
        HttpSession session = rq.getSession();
        session.setMaxInactiveInterval(60);//在服务端session的值保存的时间，单位s
//      String uuid = UUID.randomUUID().toString();
        String uuid = session.getId();
        session.setAttribute(uuid,openid+"&"+session_key);
        //查询数据库中该openid是否存在
        System.out.println("的点点滴滴==="+ump.queryOpenid(openid));
        if(ump.queryOpenid(openid)==null){
            //status为2，用户openid未存在
            map.put("status", 2);
            map.put("userInfo",u);
            ump.inserts(u);//将新用户添加到数据库
        }else{
            System.err.println("当前用户已存在数据库");
            //status为1，用户openid已存在
            map.put("status", 1);
            map.put("userInfo",u);
        }

        return map;
    }

}
