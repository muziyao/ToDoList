package com.court.controller;


import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author haiger412
 * @since 2019-10-07
 */
@RestController
@RequestMapping("/court")
@Api(tags = "球场分类相关接口")
public class CourtController {

}
