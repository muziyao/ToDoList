package com.court.controller;

import com.alibaba.fastjson.JSONObject;
import com.court.entity.Task;
import com.court.entity.UserTask;
import com.court.mapper.TaskMapper;
import com.court.mapper.UserTaskMapper;
import com.utils.DateTime;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//  http://localhost:9983/court/task/getall.action
@RestController
@RequestMapping("/task")
@Api(tags = "待办事务接口")
public class TaskController {
    @Autowired
    private TaskMapper tmp;
    @Autowired
    private UserTaskMapper utmp;


    @GetMapping("/getAllToDay.action")
    @ApiOperation(value = "获取该用户今天的所有待办事项")
    public List<Task> getAllToDay(HttpServletRequest rq, HttpServletResponse rp ) {
        System.err.println(rq.getParameter("openId"));
        System.err.println(DateTime.getToDayYearMonthDate());
        return tmp.getAll(rq.getParameter("openId"), DateTime.getToDayYearMonthDate()) ;
    }

    @GetMapping("/getAllHistory.action")
    @ApiOperation(value = "获取该用户某个日期的所有待办事项")
    public List<Task> getAllHistory(HttpServletRequest rq, HttpServletResponse rp) {
        System.err.println(rq.getParameter("openId"));
        System.err.println(rq.getParameter("times"));
        return tmp.getAll(rq.getParameter("openId"), rq.getParameter("times")) ;
    }

    @GetMapping("/insert.action")
    @ApiOperation(value = "从后台拿到新增的待办事务数据")
    public void inserts(HttpServletRequest rq, HttpServletResponse rp ) {
        System.out.println("进来task/insert.action请求路径");
        Task t = new Task();
        t.setTimes(rq.getParameter("times"));
        t.setAffair(rq.getParameter("affair"));
        tmp.inserts(t);
        UserTask ut = new UserTask();
        ut.setOpenId(rq.getParameter("openId"));
        ut.setTaskId(tmp.queryLastId());
        utmp.inserts(ut);
    }

    @RequestMapping("/setAdd.action")
    @ApiOperation(value = "从前台接收数据")
    public void setAdd(HttpServletRequest rq, HttpServletResponse rp){
        System.out.println(rq.getMethod());
        Task t = new Task();
        t.setAffair(rq.getParameter("affair"));
        t.setTimes(rq.getParameter("times"));
        t.setState(rq.getParameter("taste"));
        System.out.println(t.toString());
        tmp.inserts(t);
        UserTask ut = new UserTask();
        ut.setOpenId("");
        ut.setTaskId(tmp.queryLastId());
        utmp.inserts(ut);
    }

    @GetMapping("/deleteTask.action")
    @ApiOperation(value = "删除该用户的所有更改信息")
    public void deleteTask(HttpServletRequest rq, HttpServletResponse rp) {
        System.out.println("进来DeleteTask.action");
        // 将字符jie串转为List数组
        List<Task> TaskList = JSONObject.parseArray(rq.getParameter("task"), Task.class);
        for (Task task : TaskList) {
            System.err.println(task.getId());
        }

        //在判断前端是否传来需要更改的数据进行添加
        if( TaskList.get(0).getId()!=-1 ){
            utmp.deleteUserTask(TaskList);
            tmp.deleteTask(TaskList);
            tmp.updateTask(TaskList);
        }else{//该日期的待办事务全部删除
            String times = TaskList.get(0).getTimes();
            System.out.println(times);
            utmp.deleteAll(times);
            tmp.deleteAll(times);
        }

    }
}
