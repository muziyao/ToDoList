package com;


 
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.web.context.request.WebRequestInterceptor;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.handler.MappedInterceptor;

import com.google.common.base.Predicates;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

 
 
@EnableWebMvc
@Configuration
@ComponentScan(basePackages= {"com.court.controller"})
@Import(SwaggerConfig.class)
public class WebConfig extends WebMvcConfigurerAdapter{
	protected static final Logger logger = LogManager.getLogger();
	   @Override
	    public void addResourceHandlers(ResourceHandlerRegistry registry) {

		   registry.addResourceHandler("/swagger-ui.html")
				   .addResourceLocations("classpath:/META-INF/resources/");

		   registry.addResourceHandler("/webjars/**")
				   .addResourceLocations("classpath:/META-INF/resources/webjars/");

	   }

	  
	/**
	 * 拦截器。
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		 MappedInterceptor mapinterceptor = new MappedInterceptor(new String[] {"/task/*","/user/*.action"}, (HandlerInterceptor) new Login());
		 registry.addInterceptor(mapinterceptor);
	}
	
	/**
	 * 统一异常处理。
	 */
	@Override
	public void configureHandlerExceptionResolvers(List<HandlerExceptionResolver> exceptionResolvers) {
		exceptionResolvers.add( new  HandlerExceptionResolver() {
			
			@Override
			public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
					Exception ex) {
				StackTraceElement []trs = ex.getStackTrace();
				for(StackTraceElement t :trs ){
					 logger.error( "         "+t.getClassName() +"." +t.getMethodName() +"("+ t.getFileName()+"文件的第"+t.getLineNumber()+"行)");
				}
				logger.error("异常原因："+ex.getMessage());
				return null;
			}
		});
	}
	 
}

